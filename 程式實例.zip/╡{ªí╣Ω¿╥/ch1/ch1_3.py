# ch1_3.py
import itertools

x = ['1', '2', '3']
perm = itertools.permutations(x)
for i in perm:
    print(i)


















