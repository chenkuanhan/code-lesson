# ch5_1.py
fruits = []
fruits.append('Grape')
fruits.append('Mango')
fruits.append('Apple')
print('列印 fruits = ', fruits)
print('pop操作 : ', fruits.pop())
print('pop操作 : ', fruits.pop())
print('pop操作 : ', fruits.pop())

















