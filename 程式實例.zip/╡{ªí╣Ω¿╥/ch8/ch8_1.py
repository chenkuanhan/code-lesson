# ch8_1.py
product_list = {}                   # 產品列表的字典
product_list['Refrigerator'] = 8000
product_list['Television'] = 12000
product_list['Printer'] = 8000
print("列印產品資料")
print(product_list)
print("列印 Refrigerator : ", product_list['Refrigerator'])
print("列印 Television   : ", product_list['Television'])
print("列印 Printer      : ", product_list['Printer'])

