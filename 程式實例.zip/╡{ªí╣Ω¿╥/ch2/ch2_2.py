# ch2_2.py
from array import *
x = array('i', [5, 15, 25, 35, 45])     # 建立無號整數陣列

print(x[0])
print(x[2])
print(x[4])





