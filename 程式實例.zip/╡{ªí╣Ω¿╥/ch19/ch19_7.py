# ch19_7.py

h = eval(input('請輸入頭的數量 : '))
f = eval(input('請輸入腳的數量 : '))
chicken = f / 2 - h
rabbit = 2 * h - f / 2
print('雞有 {} 隻, 兔有 {} 隻'.format(int(chicken), int(rabbit)))





